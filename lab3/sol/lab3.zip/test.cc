// void printInt(int x) { }
// void printDouble(double x) { }

int
main() {
	int abc = 13;
	dada(1);
}

void dada(int i) {
	printInt(i);
}
