module Compiler where

import Control.Monad
import Control.Monad.State
--import System.Environment (getArgs)
--import System.Exit (exitFailure)
import Prelude hiding (id,exp)
import Data.Maybe (fromMaybe)
import qualified Data.Map as Map
import Data.Map (Map)
import Data.List (delete)


import AbsCPP
--import AnnotatingTypeChecker
--import LexCPP
--import ParCPP
import PrintCPP
--import ErrM
import Debug.Trace

-- iadd
-- isub
-- imul
-- bipush 
-- iload (loads value from stack)
-- istore (stores value to stack)
-- dup
-- 
-- invokestatic
-- goto
-- ifeq

compile :: String -> Program -> String
compile name p = unlines $ reverse $ code $ execState (compileProgram name p) (emptyEnv name)

compileProgram :: String -> Program -> State Env ()
compileProgram name (PDefs defs) = do
  -- Add all functions to environment
  mapM_ (\fn@(DFun _typ id _args _stms) ->  addFun id fn) defs

  mapM_ emit $ trace "helo" [
    ".class public " ++ name,
    ".super java/lang/Object",
    "",
    ".method public <init>()V",
    "aload_0",
    "invokenonvirtual java/lang/Object/<init>()V",
    "return",
    ".end method",
    "",
    ".method public static main([Ljava/lang/String;)V",
    ".limit locals 100",
    ".limit stack 1000"
   ]

  -- Compile all statements in main
  main@(DFun _typ _id _args stms) <- lookupFun $ Id "main"
  mapM_ compileStm stms

  emit $ trace "emitting return" "return"
  emit ".end method"


  -- remove main from environment (or not!? from local defs instead!?)
  let normalDefs = delete main defs
  -- compile all others in environment (or not!? all remaining local defs instead!?
  mapM_ compileDef normalDefs


-- Does definitions alter environment?
compileDef :: Def -> State Env ()
compileDef (DFun typ (Id name) args stms) = do
  let argTypes' = typesToString $ argTypes args
  let typ'  = typeToString typ
  emit $ ".method public static "++name++"("++argTypes'++")"++typ'
  emit ".limit locals 100"
  emit ".limit stack 1000"
  --a <- newBlock

  -- Add all parameters to current block
  mapM_ (\(ADecl typ'' id) -> addVar id typ'') args
  -- Compile all statements
  mapM_ compileStm stms

  --exitBlock a
  emit ".end method"

typesToString :: [Type] -> String
typesToString = concatMap typeToString 

typeToString :: Type -> String
typeToString typ = case typ of
                   Type_double -> "D"
                   Type_int    -> "I"
                   Type_void   -> "V"


compileStm :: Stm -> State Env ()
compileStm stm = trace ("compileStm "++printTree stm) $ case stm of
  -- TODO pop if return value, not if void. Need ETyped for this though? Assume only void SExo
  SExp exp -> compileExp exp
  SDecls typ vars -> mapM_ (`addVar` typ) vars
  SInit typ id exp -> do addVar id typ
                         a <- lookupVar id
                         compileExp exp -- (this adds value to stack)
                         emitTyped typ $ "store " ++ show a
  -- Assume no void or double returns
  SReturn exp -> do compileExp exp
                    emit "ireturn"
  SBlock stms -> do
    a <- newBlock
    mapM_ compileStm stms -- todo save return value?
    exitBlock a

  SWhile exp stm' -> do
                        l1 <- newLabel
                        l2 <- newLabel
                        let  test = 'L' : show l1
                             end  = 'L' : show l2
                        emit $ test ++ ":"
                        compileExp exp
                        emit $ "ifeq " ++ read end
                        compileStm stm'
                        emit $ "goto " ++ read test
                        emit $ end ++ ":"

  SIfElse exp stm1 stm2 -> do
                            l1 <- newLabel
                            l2 <- newLabel
                            let true  = 'L' : show l1
                                false = 'L' : show l2
                            compileExp exp
                            emit $ "ifeq " ++ read false
                            compileStm stm1
                            emit $ "goto " ++ read true
                            emit $ false ++ ":"
                            compileStm stm2
                            emit $ true ++ ":"



compileExp :: Exp -> State Env ()
compileExp e = trace ("compileExp"++printTree e) $ case e of
  EId x  -> do
    a <- trace "looking up" $ lookupVar x
    emit ("iload " ++ show a)
  EInt i    -> emit ("bipush " ++ show i)
  EDouble d -> emit ("ldc2_w " ++ show d)
  EPlus e1 e2 -> do
    compileExp e1
    compileExp e2
    emit "iadd"
  EAss (EId id) exp -> do
    compileExp exp
    a <- lookupVar id
    emit "dup"
    emit ("istore " ++ show a) 

    -- TODO assign arguments with param names in "addresses" or somewhere?

  EApp (Id s) args -> do
    -- Compile arguments
    mapM_ compileExp $ trace "compiling arguments" args
    env <- get
    -- Get function and its parts from environment
    let (DFun typ _id params _stms) = functions env Map.! Id s
    let argsTypes' = typesToString $ argTypes params
    let typ'  = typeToString typ

    a <- newBlock
    emit $ case s of
      "printInt"    -> "invokestatic Runtime/printInt(I)V"
      "readInt"     -> "invokestatic Runtime/readInt()I"
      _             -> "invokestatic "++progName env++"/"++s++"("++argsTypes'++")"++typ'
    exitBlock a

  EString s -> emit $ "ldc " ++ show s
  EMinus exp1 exp2 -> do
    compileExp exp1
    compileExp exp2
    emit "isub"
  ETimes exp1 exp2 -> do
    compileExp exp1
    compileExp exp2
    emit "imul"
  EDiv exp1 exp2 -> do
    compileExp exp1
    compileExp exp2
    emit "idiv"
  EIncr (EId x) -> do
    a <- lookupVar x
    emit $ "iload " ++ show a
    emit "dup"
    emit "bipush 1"
    emit "iadd"
    emit $ "istore " ++ show a
  EPIncr (EId x) -> do
    a <- lookupVar x
    emit $ "iload " ++ show a
    emit "bipush 1"
    emit "iadd"
    emit "dup"
    emit $ "istore " ++ show a
  EDecr (EId x) -> do
    a <- lookupVar x
    emit $ "iload " ++ show a
    emit "dup"
    emit "bipush 1"
    emit "isub"
    emit $ "istore " ++ show a
  EPDecr (EId x) -> do
    a <- lookupVar x
    emit $ "iload " ++ show a
    emit "bipush 1"
    emit "isub"
    emit "dup"
    emit $ "istore " ++ show a
  _ -> return $ trace "OAOAS" ()


data Env = E {
  progName        :: String, -- The program name
  addresses   :: [[(Id,Address)]], -- Map from variable names to stack adresses
  nextLabel   :: Int, -- used in newLabel
  nextAddress :: Address, -- used in addVar
  maxAddress  :: Address, -- .limit locals
  maxSize     :: Int, -- .limit stack
  code        :: [Instruction],
  functions   :: Map Id Def
  }

emptyEnv :: String -> Env
emptyEnv name = E {
  progName = name,
  addresses = [[]],
  nextLabel = 0,
  nextAddress = 1,
  maxAddress = 1,
  maxSize = 1,
  code = [],
  functions = Map.empty
  }

type Instruction = String
type Address = Int

-- A function and its various auxiliary functions
getParamTypes :: Def -> [Type]
getParamTypes (DFun _typ _id args _stms) = map (\(ADecl t _id) -> t) args
getParamNames :: Def -> [Id]
getParamNames (DFun _typ _id args _stms) = map (\(ADecl _t id) -> id) args
getReturnType :: Def -> Type
getReturnType (DFun typ _id _args _stms) = typ

argTypes :: [Arg] -> [Type]
argTypes = map (\(ADecl typ' _) -> typ')

-- Adds a function to the environment
addFun :: Id -> Def -> State Env ()
addFun id fn = modify (\env -> env {
  functions = Map.insert id fn (functions env)
  })
-- Looks up a function in the environment
lookupFun :: Id -> State Env Def
lookupFun id = do
  env <- get
  return $ functions env Map.! id 


emit :: Instruction -> State Env ()
emit i = modify (\env -> env{code = i : code env})

emitTyped :: Type -> Instruction -> State Env ()
emitTyped t i = emit (c ++ i)
  where c = case t of
              Type_int -> "i"
              Type_double -> "d"

addVar :: Id -> Type -> State Env ()
addVar x t = modify (\env -> env {
  addresses = case addresses env of (scope:rest) -> ((x,nextAddress env):scope):rest,
  nextAddress = nextAddress env + typeSize t
  })

lookupVar :: Id -> State Env Address
lookupVar x = do
  env <- get
  return $ look (addresses env) x 
 where
   look [] x' = error $ "Unknown variable " ++ printTree x' ++ "."
   look (scope:rest) x' = fromMaybe (look rest x') (lookup x' scope)

typeSize :: Type -> Int
typeSize t = case t of
  Type_int -> 1
  Type_double -> 2

newBlock :: State Env Address
newBlock = do
  modify (\env -> env {addresses = [] : addresses env})
  env <- get
  return $ nextAddress env

exitBlock :: Address -> State Env ()
exitBlock a = modify (\env -> env {
   addresses = tail (addresses env),
   nextAddress = a
   })

newLabel :: State Env Int
newLabel = do env <- get
              modify (\env' -> env' {nextLabel = nextLabel env' + 1} )
              return $ nextLabel env
